function trocaCor(cor){
    let circulo = document.querySelector(".circulo")
    circulo.style.background = cor
}

function trocaIphone(iphone){
    let imgIphone = document.querySelector(".foto-iphone")
    imgIphone.src = iphone
}